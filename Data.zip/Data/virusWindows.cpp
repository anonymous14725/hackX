#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <fstream>
using namespace std;

int main(){
	system("touch hi.txt");
	ofstream hackW;
	hackW.open("hi.txt");
	hackW << "del autoexec.bat del config.sys cd winnt del system.ini del win.ini";
	hackW.close();

	std::chrono::seconds time(1);
	std::this_thread::sleep_for(time);
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";  
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^^^";
	
	cout << "^_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "__";
	
	cout << "__";
	
	cout << "__";
	std::chrono::seconds timess(1);
	std::this_thread::sleep_for(timess);
	
	cout << "___" << endl;
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "_";
	
	cout << "__"; 
	
	cout << "_";
	
	cout << "__";
	
	cout << "__";
	
	cout << "__";
	
	cout << "__";
	
	cout << "s";
	
	cout << "u";
	
	cout << "c";
	
	cout << "c";
	
	cout << "e";
	
	cout << "s";
	
	cout << "s";
	
	cout << "f";
	
	cout << "u";
	
	cout << "l ";
	
	cout << "v";
	
	cout << "i";
	
	cout << "r";
	
	cout << "u";
	
	cout << "s";
	
	cout << "__";
	
	cout << "___";
	
	cout << "____";
	
	cout << "_____";
	std::chrono::seconds times(1);
	std::this_thread::sleep_for(times);
	
	cout << "__" << endl;
	
	cout << "___";
	
	cout << "____";
	
	cout << "_____";
	
	cout << "______";
	
	cout << "_______";
	
	cout << "________";
	
	cout << "_________";
	
	cout << "_____" << endl;

	return 0;
}

